webpackJsonp([5],{

/***/ "DLm/":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/is.js
var is = __webpack_require__("g4PW");
var is_default = /*#__PURE__*/__webpack_require__.n(is);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/ServerManage.vue

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _serverManageTableThis = null;
/* harmony default export */ var ServerManage = ({
    name: 'serverManageTable',
    beforeCreate: function beforeCreate() {
        _serverManageTableThis = this; //将当前组件this赋值给_this对象
    },
    data: function data() {
        return {
            tableData: [],
            currentPage: 0,
            pageSize: 20,
            totalSize: 0,
            editVisible: false, //控制编辑弹出框是否显示
            createVisible: false, //控制创建弹出框是否显示
            multipleSelection: [], //选中多行的数据缓存
            form: {
                id: "",
                serverAddress: "",
                monitorPort: "",
                serverName: "",
                status: "",
                createTime: ""
            },
            searchForm: {
                serverAddress: "",
                id: "",
                serverName: ""
            },
            statuOptions: [{
                status: '0',
                label: '未启动'
            }, {
                status: '1',
                label: '运行正常'
            }],
            rules: {
                serverAddress: [{ required: true, trigger: ['blur'], validator: this.$checker, test: this.$verifyRules.ipv4.test, istrim: true, message: this.$verifyRules.ipv4.message }],
                monitorPort: [{ required: true, trigger: ['blur'], validator: this.$checker, test: this.$verifyRules.serverPort.test, istrim: true, message: this.$verifyRules.serverPort.message }]
            }
        };
    },
    created: function created() {
        _serverManageTableThis.getData();
    },

    methods: {
        // 分页导航
        handleCurrentChange: function handleCurrentChange(val) {
            _serverManageTableThis.currentPage = val - 1;
            _serverManageTableThis.getData();
        },

        //获取数据
        getData: function getData() {
            if (!_serverManageTableThis.currentPage) {
                _serverManageTableThis.currentPage = 0;
            }
            if (!_serverManageTableThis.pageSize) {
                _serverManageTableThis.pageSize = 20;
            }
            var queryParam = {};
            queryParam.currentPage = _serverManageTableThis.currentPage;
            queryParam.pageSize = _serverManageTableThis.pageSize;
            if (_serverManageTableThis.searchForm.serverAddress && !is_default()('', _serverManageTableThis.searchForm.serverAddress.trim())) {
                queryParam.serverAddress = _serverManageTableThis.searchForm.serverAddress.trim();
            }
            if (_serverManageTableThis.searchForm.id && !is_default()('', _serverManageTableThis.searchForm.id.trim())) {
                queryParam.id = _serverManageTableThis.searchForm.id.trim();
            }
            if (_serverManageTableThis.searchForm.serverName && !is_default()('', _serverManageTableThis.searchForm.serverName.trim())) {
                queryParam.serverName = _serverManageTableThis.searchForm.serverName.trim();
            }
            this.$axios.post(this.BASE_URLD + '/serverManagement/query', queryParam).then(function (response) {
                _serverManageTableThis.tableData = response.data.returnData;
                _serverManageTableThis.pageSize = response.data.pageSize;
                _serverManageTableThis.currentPage = response.data.currentPage + 1;
                _serverManageTableThis.totalSize = response.data.totalSize;
            });
        },
        search: function search() {
            _serverManageTableThis.currentPage = 0;
            _serverManageTableThis.getData();
        },

        //转换服务器状态
        formatterStatus: function formatterStatus(row, column) {
            var returnStr = "";
            if (is_default()('0', row.status)) {
                returnStr = '未启动';
            }
            if (is_default()('1', row.status)) {
                returnStr = '运行正常';
            }
            return returnStr;
        },

        //格式化日期
        formatterDate: function formatterDate(row, column) {
            return this.$moment(row.createTime).format('YYYY-MM-DD HH:mm:ss');
        },

        //设置表头背景颜色
        getRowClass: function getRowClass(_ref) {
            var row = _ref.row,
                column = _ref.column,
                rowIndex = _ref.rowIndex,
                columnIndex = _ref.columnIndex;

            if (rowIndex == 0) {
                return 'background:#EFEFEF';
            } else {
                return '';
            }
        },
        handleCreateServer: function handleCreateServer() {
            _serverManageTableThis.form = {
                serverAddress: "",
                monitorPort: "",
                serverName: "",
                status: "1"
            };
            _serverManageTableThis.createVisible = true;
            this.$nextTick(function () {
                this.$refs["form"].clearValidate();
            });
        },
        handleEditServer: function handleEditServer() {
            if (_serverManageTableThis.multipleSelection.length > 1) {
                _serverManageTableThis.$message.error('编辑失败！最多选择一行。');
                return;
            }
            if (_serverManageTableThis.multipleSelection.length <= 0 || !_serverManageTableThis.multipleSelection) {
                _serverManageTableThis.$message.error('编辑失败！至少选择一行。');
                return;
            }
            var item = _serverManageTableThis.multipleSelection[0];
            _serverManageTableThis.form = {
                id: item.id,
                serverAddress: item.serverAddress,
                monitorPort: item.monitorPort,
                serverName: item.serverName,
                status: item.status,
                createTime: item.createTime
            };
            _serverManageTableThis.editVisible = true;
        },
        handleEnableServer: function handleEnableServer() {
            var _this = this;

            if (_serverManageTableThis.multipleSelection.length <= 0 || !_serverManageTableThis.multipleSelection) {
                _serverManageTableThis.$message.error('启用失败！至少选择一行。');
                return;
            }
            var idxCnt = _serverManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _serverManageTableThis.multipleSelection[idx];
                _serverManageTableThis.form = {
                    id: item.id,
                    serverAddress: item.serverAddress,
                    monitorPort: item.monitorPort,
                    serverName: item.serverName,
                    status: item.status,
                    createTime: item.createTime
                };
                this.$axios.post(this.BASE_URLD + '/serverManagement/enable', _serverManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _serverManageTableThis.$message.success('服务器启用成功，服务器IP：' + _serverManageTableThis.form.serverAddress + '。');
                        _serverManageTableThis.editVisible = false;

                        _serverManageTableThis.currentPage = 0;
                        _serverManageTableThis.getData();
                    } else {
                        _this.$alert('启用失败！' + response.data.returnMessage + '，服务器IP：' + _serverManageTableThis.form.serverAddress + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('启用失败！服务器异常，请联系管理员，服务器IP：' + _serverManageTableThis.form.serverAddress + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        handleDisableServer: function handleDisableServer() {
            var _this2 = this;

            if (_serverManageTableThis.multipleSelection.length <= 0 || !_serverManageTableThis.multipleSelection) {
                _serverManageTableThis.$message.error('停用失败！至少选择一行。');
                return;
            }
            var idxCnt = _serverManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _serverManageTableThis.multipleSelection[idx];
                _serverManageTableThis.form = {
                    id: item.id,
                    serverAddress: item.serverAddress,
                    monitorPort: item.monitorPort,
                    serverName: item.serverName,
                    status: item.status,
                    createTime: item.createTime
                };
                this.$axios.post(this.BASE_URLD + '/serverManagement/disable', _serverManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _serverManageTableThis.$message.success('服务器停用成功，服务器IP：' + _serverManageTableThis.form.serverAddress + '。');
                        _serverManageTableThis.editVisible = false;

                        _serverManageTableThis.currentPage = 0;
                        _serverManageTableThis.getData();
                    } else {
                        _this2.$alert('停用失败！' + response.data.returnMessage + '，服务器IP：' + _serverManageTableThis.form.serverAddress + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        _serverManageTableThis.currentPage = 0;
                        _serverManageTableThis.getData();
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('停用失败！服务器异常，请联系管理员，服务器IP：' + _serverManageTableThis.form.serverAddress + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        handleOperate: function handleOperate(command) {
            if (is_default()('createServer', command)) {
                _serverManageTableThis.handleCreateServer();
                return;
            }
            if (is_default()('editServer', command)) {
                _serverManageTableThis.handleEditServer();
                return;
            }
            if (is_default()('enableServer', command)) {
                _serverManageTableThis.handleEnableServer();
                return;
            }
            if (is_default()('disableServer', command)) {
                _serverManageTableThis.handleDisableServer();
                return;
            }
        },

        //处理单击列表选择框
        handleSelectionChange: function handleSelectionChange(vals) {
            _serverManageTableThis.multipleSelection = vals;
        },

        // 编辑保存
        saveEdit: function saveEdit() {
            this.$axios.post(this.BASE_URLD + '/serverManagement/update', _serverManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _serverManageTableThis.$message.success('服务器信息更新成功。');
                    _serverManageTableThis.editVisible = false;

                    _serverManageTableThis.currentPage = 0;
                    _serverManageTableThis.getData();
                } else {
                    _serverManageTableThis.$message.error('更新失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _serverManageTableThis.$message.error("更新失败！服务器异常，请联系管理员。");
            });
        },

        // 创建保存
        saveCreate: function saveCreate() {
            if (!_serverManageTableThis.form.serverAddress || is_default()('', _serverManageTableThis.form.serverAddress)) {
                _serverManageTableThis.$message.error('创建失败！IP地址不能为空。');
                return;
            }
            if (!_serverManageTableThis.form.monitorPort || is_default()('', _serverManageTableThis.form.monitorPort)) {
                _serverManageTableThis.$message.error('创建失败！管理端口不能为空。');
                return;
            }
            this.$axios.post(this.BASE_URLD + '/serverManagement/create', _serverManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _serverManageTableThis.$message.success('服务器信息创建成功。');
                    _serverManageTableThis.createVisible = false;

                    _serverManageTableThis.currentPage = 0;
                    _serverManageTableThis.getData();
                } else {
                    _serverManageTableThis.$message.error('创建失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _serverManageTableThis.$message.error("创建失败！服务器异常，请联系管理员。");
            });
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-54314ba4","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/ServerManage.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"table"},[_c('div',{staticClass:"crumbs"},[_c('el-breadcrumb',{attrs:{"separator":"/"}},[_c('el-breadcrumb-item',[_c('i',{staticClass:"el-icon-hy-electronics"}),_vm._v(" 服务器管理")])],1)],1),_vm._v(" "),_c('div',{staticClass:"container"},[_c('div',{staticClass:"handle-box"},[_c('el-dropdown',{on:{"command":_vm.handleOperate}},[_c('el-button',{attrs:{"size":"mini","type":"primary"}},[_c('i',{staticClass:"el-icon-hy-caozuo-shezhi",staticStyle:{"font-size":"10px !important"}}),_vm._v("  操 作\n                ")]),_vm._v(" "),_c('el-dropdown-menu',{attrs:{"slot":"dropdown","size":"small","divided":"true","placement":"bottom-start"},slot:"dropdown"},[_c('el-dropdown-item',{attrs:{"command":"createServer"}},[_vm._v("新增")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"editServer"}},[_vm._v("编辑")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"enableServer"}},[_vm._v("启用")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"disableServer"}},[_vm._v("停用")])],1)],1),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"IP地址","clearable":true},model:{value:(_vm.searchForm.serverAddress),callback:function ($$v) {_vm.$set(_vm.searchForm, "serverAddress", $$v)},expression:"searchForm.serverAddress"}}),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"服务器编号","clearable":true},model:{value:(_vm.searchForm.id),callback:function ($$v) {_vm.$set(_vm.searchForm, "id", $$v)},expression:"searchForm.id"}}),_vm._v(" "),_c('el-input',{staticClass:"handle-input-200 mr10",attrs:{"placeholder":"服务器名称","clearable":true},model:{value:(_vm.searchForm.serverName),callback:function ($$v) {_vm.$set(_vm.searchForm, "serverName", $$v)},expression:"searchForm.serverName"}}),_vm._v(" "),_c('el-button',{attrs:{"type":"primary","icon":"search"},on:{"click":_vm.search}},[_vm._v("搜索")])],1),_vm._v(" "),_c('div',{staticClass:"data-table"},[_c('el-table',{ref:"multipleTable",staticClass:"table",attrs:{"data":_vm.tableData,"border":"","header-cell-style":_vm.getRowClass},on:{"selection-change":_vm.handleSelectionChange}},[_c('el-table-column',{attrs:{"type":"selection","width":"55","align":"center"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"id","label":"服务器编号","width":"120"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"serverName","label":"服务器名称","width":"300"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"serverAddress","label":"IP地址","width":"150"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"monitorPort","label":"管理端口","width":"120"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"status","label":"状态","width":"120","formatter":_vm.formatterStatus}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"createTime","label":"创建时间","formatter":_vm.formatterDate}})],1),_vm._v(" "),_c('div',{staticClass:"pagination"},[_c('el-pagination',{attrs:{"background":"","layout":"prev, pager, next","prev-text":"上一页","next-text":"下一页","page-size":_vm.pageSize,"current-page":_vm.currentPage,"total":_vm.totalSize},on:{"current-change":_vm.handleCurrentChange}})],1)],1)]),_vm._v(" "),_c('el-dialog',{attrs:{"title":"编辑服务器信息","visible":_vm.editVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.editVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"rules":_vm.rules,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"服务器名称","prop":"serverName"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"服务器名称..."},model:{value:(_vm.form.serverName),callback:function ($$v) {_vm.$set(_vm.form, "serverName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.serverName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"IP地址","prop":"serverAddress"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"服务器IP...","disabled":true},model:{value:(_vm.form.serverAddress),callback:function ($$v) {_vm.$set(_vm.form, "serverAddress", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.serverAddress"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"管理端口","prop":"monitorPort"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"管理端口...","disabled":true},model:{value:(_vm.form.monitorPort),callback:function ($$v) {_vm.$set(_vm.form, "monitorPort", _vm._n($$v))},expression:"form.monitorPort"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"状态"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"placeholder":"运行状态..."},model:{value:(_vm.form.status),callback:function ($$v) {_vm.$set(_vm.form, "status", $$v)},expression:"form.status"}},_vm._l((_vm.statuOptions),function(item){return _c('el-option',{key:item.status,attrs:{"label":item.label,"value":item.status}})}),1)],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.editVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveEdit}},[_vm._v("确 定")])],1)],1),_vm._v(" "),_c('el-dialog',{attrs:{"title":"创建服务器信息","visible":_vm.createVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.createVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"rules":_vm.rules,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"服务器名称","prop":"serverName"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"服务器名称..."},model:{value:(_vm.form.serverName),callback:function ($$v) {_vm.$set(_vm.form, "serverName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.serverName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"IP地址","prop":"serverAddress"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"服务器IP..."},model:{value:(_vm.form.serverAddress),callback:function ($$v) {_vm.$set(_vm.form, "serverAddress", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.serverAddress"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"管理端口","prop":"monitorPort"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"管理端口..."},model:{value:(_vm.form.monitorPort),callback:function ($$v) {_vm.$set(_vm.form, "monitorPort", _vm._n($$v))},expression:"form.monitorPort"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"状态"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"placeholder":"运行状态..."},model:{value:(_vm.form.status),callback:function ($$v) {_vm.$set(_vm.form, "status", $$v)},expression:"form.status"}},_vm._l((_vm.statuOptions),function(item){return _c('el-option',{key:item.status,attrs:{"label":item.label,"value":item.status}})}),1)],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.createVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveCreate}},[_vm._v("确 定")])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_ServerManage = (esExports);
// CONCATENATED MODULE: ./src/components/page/ServerManage.vue
function injectStyle (ssrContext) {
  __webpack_require__("kHYp")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-54314ba4"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  ServerManage,
  page_ServerManage,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_ServerManage = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "kHYp":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })

});