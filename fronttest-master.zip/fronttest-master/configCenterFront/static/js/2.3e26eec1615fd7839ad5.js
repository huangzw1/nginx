webpackJsonp([2],{

/***/ "2UrJ":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "GF4k":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/Login.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Login = ({
    data: function data() {
        var check = function check(rule, value, callback) {
            var matcher = new RegExp(rule.test);
            if (matcher.test(value)) {
                callback();
            } else {
                callback(new Error(rule.message));
            }
        };
        return {
            loginWrap: {
                position: "relative",
                width: "100%",
                height: "100%",
                backgroundImage: "url(" + __webpack_require__("Xcss") + ")",
                backgroundSize: "100%"
            },
            ruleForm: {
                userId: "",
                userPass: ""
            },
            rules: {
                userId: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
                userPass: [{ required: true, message: '请输入密码', trigger: 'blur' }]
            }
        };
    },
    methods: {
        submitForm: function submitForm(formName) {
            var _this = this;

            this.$refs[formName].validate(function (valid) {
                if (valid) {
                    _this.$axios.post(_this.BASE_URLD + '/userManagement/login', {
                        userId: _this.ruleForm.userId,
                        userPass: _this.$md5(_this.ruleForm.userPass)
                    }).then(function (response) {
                        if (response.data.userId) {
                            _this.$session['userId'] = response.data.userId;
                            _this.$session['userName'] = response.data.userName;
                            _this.$router.push('/');
                        } else {
                            _this.$alert('登录失败，请刷新后重试！', "登录失败提示", {
                                confirmButtonText: '确定',
                                callback: function callback(action) {
                                    _this.$router.push('/login');
                                }
                            });
                        }
                    }).catch(function (error) {
                        _this.loading = false;
                        console.log(error);
                        _this.$alert('登录失败，请刷新后重试！', "登录失败提示", {
                            confirmButtonText: '确定',
                            callback: function callback(action) {
                                _this.$router.push('/login');
                            }
                        });
                    });
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-6eba263a","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/Login.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{style:(_vm.loginWrap)},[_c('div',{staticClass:"ms-login"},[_c('div',{staticClass:"ms-title"},[_vm._v("数据采集后台管理系统")]),_vm._v(" "),_c('el-form',{ref:"ruleForm",staticClass:"ms-content",attrs:{"model":_vm.ruleForm,"rules":_vm.rules,"label-width":"0px"}},[_c('el-form-item',{attrs:{"prop":"userId"}},[_c('el-input',{attrs:{"placeholder":"手机号"},model:{value:(_vm.ruleForm.userId),callback:function ($$v) {_vm.$set(_vm.ruleForm, "userId", $$v)},expression:"ruleForm.userId"}},[_c('el-button',{attrs:{"slot":"prepend","icon":"el-icon-hy-yonghu"},slot:"prepend"})],1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"prop":"userPass"}},[_c('el-input',{attrs:{"type":"password","placeholder":"登录密码"},nativeOn:{"keyup":function($event){if(!('button' in $event)&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }_vm.submitForm('ruleForm')}},model:{value:(_vm.ruleForm.userPass),callback:function ($$v) {_vm.$set(_vm.ruleForm, "userPass", $$v)},expression:"ruleForm.userPass"}},[_c('el-button',{attrs:{"slot":"prepend","icon":"el-icon-hy-mima1"},slot:"prepend"})],1)],1),_vm._v(" "),_c('div',{staticClass:"login-btn"},[_c('el-button',{attrs:{"type":"primary"},on:{"click":function($event){_vm.submitForm('ruleForm')}}},[_vm._v("登录")])],1)],1)],1)])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_Login = (esExports);
// CONCATENATED MODULE: ./src/components/page/Login.vue
function injectStyle (ssrContext) {
  __webpack_require__("2UrJ")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-6eba263a"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  Login,
  page_Login,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_Login = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "Xcss":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/login-bg.af57b94.jpg";

/***/ })

});