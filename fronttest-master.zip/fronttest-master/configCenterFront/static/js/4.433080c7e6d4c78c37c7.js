webpackJsonp([4],{

/***/ "PMJ5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/is.js
var is = __webpack_require__("g4PW");
var is_default = /*#__PURE__*/__webpack_require__.n(is);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/AppManage.vue

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _applicationManageTableThis = null;
/* harmony default export */ var AppManage = ({
    name: 'applicationManageTable',
    beforeCreate: function beforeCreate() {
        _applicationManageTableThis = this; //将当前组件this赋值给_this对象
    },
    data: function data() {
        return {
            tableData: [],
            currentPage: 0,
            pageSize: 20,
            totalSize: 0,
            editVisible: false, //控制编辑弹出框是否显示
            createVisible: false, //控制创建弹出框是否显示
            multipleSelection: [], //选中多行的数据缓存
            form: {
                id: "",
                serverId: "",
                applicationName: "",
                version: "",
                configFileName: "",
                configTemplate: "",
                notifyPhone: "",
                status: "",
                createTime: ""
            },
            searchForm: {
                serverId: "",
                id: "",
                applicationName: ""
            },
            serverOptions: [],
            statuOptions: [{
                status: '1',
                label: '启用'
            }, {
                status: '0',
                label: '停用'
            }],
            rules: {}
        };
    },
    created: function created() {
        _applicationManageTableThis.getData();
    },
    activated: function activated() {
        _applicationManageTableThis.loadServerMapping();
    },

    methods: {
        // 分页导航
        handleCurrentChange: function handleCurrentChange(val) {
            _applicationManageTableThis.currentPage = val - 1;
            _applicationManageTableThis.getData();
        },

        //获取数据
        getData: function getData() {
            if (!_applicationManageTableThis.currentPage) {
                _applicationManageTableThis.currentPage = 0;
            }
            if (!_applicationManageTableThis.pageSize) {
                _applicationManageTableThis.pageSize = 20;
            }
            this.$axios.post(this.BASE_URLD + '/appManagement/query', _applicationManageTableThis.searchForm).then(function (response) {
                _applicationManageTableThis.tableData = response.data.returnData;
                _applicationManageTableThis.pageSize = response.data.pageSize;
                _applicationManageTableThis.currentPage = response.data.currentPage + 1;
                _applicationManageTableThis.totalSize = response.data.totalSize;
            });
        },
        search: function search() {
            _applicationManageTableThis.currentPage = 0;
            _applicationManageTableThis.getData();
        },

        //转换服务器状态
        formatterStatus: function formatterStatus(row, column) {
            var returnStr = "";
            if (is_default()('1', row.status)) {
                returnStr = '启用';
            }
            if (is_default()('0', row.status)) {
                returnStr = '停用';
            }
            return returnStr;
        },

        //格式化日期
        formatterDate: function formatterDate(row, column) {
            return this.$moment(row.createTime).format('YYYY-MM-DD HH:mm:ss');
        },

        //设置表头背景颜色
        getRowClass: function getRowClass(_ref) {
            var row = _ref.row,
                column = _ref.column,
                rowIndex = _ref.rowIndex,
                columnIndex = _ref.columnIndex;

            if (rowIndex == 0) {
                return 'background:#EFEFEF';
            } else {
                return '';
            }
        },
        handleCreateApplication: function handleCreateApplication() {
            _applicationManageTableThis.form = {
                serverId: "",
                applicationName: "",
                configFileName: "",
                configTemplate: "",
                version: "",
                status: "1"
            };
            _applicationManageTableThis.createVisible = true;
        },
        handleEditApplication: function handleEditApplication() {
            if (_applicationManageTableThis.multipleSelection.length > 1) {
                _applicationManageTableThis.$message.error('编辑失败！最多选择一行。');
                return;
            }
            if (_applicationManageTableThis.multipleSelection.length <= 0 || !_applicationManageTableThis.multipleSelection) {
                _applicationManageTableThis.$message.error('编辑失败！至少选择一行。');
                return;
            }
            var item = _applicationManageTableThis.multipleSelection[0];
            _applicationManageTableThis.form = {
                id: item.id,
                serverId: item.serverId,
                applicationName: item.applicationName,
                configFileName: item.configFileName,
                configTemplate: item.configTemplate,
                version: item.version,
                status: item.status
            };
            _applicationManageTableThis.editVisible = true;
        },
        handleEnableApplication: function handleEnableApplication() {
            var _this = this;

            if (_applicationManageTableThis.multipleSelection.length <= 0 || !_applicationManageTableThis.multipleSelection) {
                _applicationManageTableThis.$message.error('启用失败！至少选择一行。');
                return;
            }
            var idxCnt = _applicationManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _applicationManageTableThis.multipleSelection[idx];
                _applicationManageTableThis.form = {
                    id: item.id,
                    serverId: item.serverId,
                    serverAddress: item.serverAddress,
                    applicationName: item.applicationName,
                    configFileName: item.configFileName,
                    configTemplate: item.configTemplate,
                    version: item.version,
                    status: item.status
                };
                this.$axios.post(this.BASE_URLD + '/appManagement/enable', _applicationManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _applicationManageTableThis.$message.success('应用启用成功，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。');
                        _applicationManageTableThis.editVisible = false;

                        _applicationManageTableThis.currentPage = 0;
                        _applicationManageTableThis.getData();
                    } else {
                        _this.$alert('启用失败！' + response.data.returnMessage + '，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('启用失败！服务器异常，请联系管理员，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        handleDisableApplication: function handleDisableApplication() {
            var _this2 = this;

            if (_applicationManageTableThis.multipleSelection.length <= 0 || !_applicationManageTableThis.multipleSelection) {
                _applicationManageTableThis.$message.error('停用失败！至少选择一行。');
                return;
            }
            var idxCnt = _applicationManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _applicationManageTableThis.multipleSelection[idx];
                _applicationManageTableThis.form = {
                    id: item.id,
                    serverId: item.serverId,
                    serverAddress: item.serverAddress,
                    applicationName: item.applicationName,
                    configFileName: item.configFileName,
                    configTemplate: item.configTemplate,
                    version: item.version,
                    status: item.status
                };
                this.$axios.post(this.BASE_URLD + '/appManagement/disable', _applicationManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _applicationManageTableThis.$message.success('应用停用成功，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。');
                        _applicationManageTableThis.editVisible = false;

                        _applicationManageTableThis.currentPage = 0;
                        _applicationManageTableThis.getData();
                    } else {
                        _this2.$alert('停用失败！' + response.data.returnMessage + '，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        _applicationManageTableThis.currentPage = 0;
                        _applicationManageTableThis.getData();
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('停用失败！服务器异常，请联系管理员，服务器IP：' + _applicationManageTableThis.form.serverAddress + '  应用名称：' + _applicationManageTableThis.form.applicationName + '  应用版本：' + _applicationManageTableThis.form.version + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        handleOperate: function handleOperate(command) {
            if (is_default()('createApplication', command)) {
                _applicationManageTableThis.handleCreateApplication();
                return;
            }
            if (is_default()('editApplication', command)) {
                _applicationManageTableThis.handleEditApplication();
                return;
            }
            if (is_default()('enableApplication', command)) {
                _applicationManageTableThis.handleEnableApplication();
                return;
            }
            if (is_default()('disableApplication', command)) {
                _applicationManageTableThis.handleDisableApplication();
                return;
            }
        },

        //处理单击列表选择框
        handleSelectionChange: function handleSelectionChange(vals) {
            _applicationManageTableThis.multipleSelection = vals;
        },

        // 编辑保存
        saveEdit: function saveEdit() {
            this.$axios.post(this.BASE_URLD + '/appManagement/update', _applicationManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _applicationManageTableThis.$message.success('应用信息更新成功。');
                    _applicationManageTableThis.editVisible = false;

                    _applicationManageTableThis.currentPage = 0;
                    _applicationManageTableThis.getData();
                } else {
                    _applicationManageTableThis.$message.error('更新失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _applicationManageTableThis.$message.error("更新失败！服务器异常，请联系管理员。");
            });
        },

        // 创建保存
        saveCreate: function saveCreate() {
            if (!_applicationManageTableThis.form.serverId || is_default()('', _applicationManageTableThis.form.serverId)) {
                _applicationManageTableThis.$message.error('创建失败！服务器信息不能为空。');
                return;
            }
            if (!_applicationManageTableThis.form.applicationName || is_default()('', _applicationManageTableThis.form.applicationName)) {
                _applicationManageTableThis.$message.error('创建失败！应用名称不能为空。');
                return;
            }
            if (!_applicationManageTableThis.form.version || is_default()('', _applicationManageTableThis.form.version)) {
                _applicationManageTableThis.$message.error('创建失败！应用版本不能为空。');
                return;
            }
            if (!_applicationManageTableThis.form.configFileName || is_default()('', _applicationManageTableThis.form.configFileName)) {
                _applicationManageTableThis.$message.error('创建失败！配置文件路径不能为空。');
                return;
            }
            if (!_applicationManageTableThis.form.configTemplate || is_default()('', _applicationManageTableThis.form.configTemplate)) {
                _applicationManageTableThis.$message.error('创建失败！配置模版不能为空。');
                return;
            }
            this.$axios.post(this.BASE_URLD + '/appManagement/create', _applicationManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _applicationManageTableThis.$message.success('应用信息创建成功。');
                    _applicationManageTableThis.createVisible = false;

                    _applicationManageTableThis.currentPage = 0;
                    _applicationManageTableThis.getData();
                } else {
                    _applicationManageTableThis.$message.error('创建失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _applicationManageTableThis.$message.error("创建失败！服务器异常，请联系管理员。");
            });
        },

        //加载服务器列表
        loadServerMapping: function loadServerMapping() {
            this.$axios.post(this.BASE_URLD + '/serverManagement/loadServerIdAndIpMapping', _applicationManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _applicationManageTableThis.serverOptions = response.data.returnData;
                } else {
                    _applicationManageTableThis.$message.error("加载服务器信息异常，请联系管理员。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _applicationManageTableThis.$message.error("加载服务器信息异常，请联系管理员。");
            });
        },

        //处理编辑或者创建应用界面中,服务器的选择事件,同步联动serverId
        handleSeclectServer: function handleSeclectServer(serverAddress) {
            var serverInfo = _applicationManageTableThis.serverOptions.find(function (item) {
                //这里的userList就是上面遍历的数据源
                return item.serverAddress === serverAddress; //筛选出匹配数据
            });
            _applicationManageTableThis.form.serverId = serverInfo.id;
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-5d3b70e4","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/AppManage.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"table"},[_c('div',{staticClass:"crumbs"},[_c('el-breadcrumb',{attrs:{"separator":"/"}},[_c('el-breadcrumb-item',[_c('i',{staticClass:"el-icon-hy-yingyong1"}),_vm._v(" 应用管理")])],1)],1),_vm._v(" "),_c('div',{staticClass:"container"},[_c('div',{staticClass:"handle-box"},[_c('el-dropdown',{on:{"command":_vm.handleOperate}},[_c('el-button',{attrs:{"size":"mini","type":"primary"}},[_c('i',{staticClass:"el-icon-hy-caozuo-shezhi",staticStyle:{"font-size":"10px !important"}}),_vm._v("  操 作\n                ")]),_vm._v(" "),_c('el-dropdown-menu',{attrs:{"slot":"dropdown","size":"small","divided":"true","placement":"bottom-start"},slot:"dropdown"},[_c('el-dropdown-item',{attrs:{"command":"createApplication"}},[_vm._v("新增")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"editApplication"}},[_vm._v("编辑")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"enableApplication"}},[_vm._v("启用")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"disableApplication"}},[_vm._v("停用")])],1)],1),_vm._v(" "),_c('el-select',{staticStyle:{"width":"150px"},attrs:{"filterable":"","placeholder":"服务器","clearable":true},model:{value:(_vm.searchForm.serverId),callback:function ($$v) {_vm.$set(_vm.searchForm, "serverId", $$v)},expression:"searchForm.serverId"}},_vm._l((_vm.serverOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.serverAddress,"value":item.id}})}),1),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"应用编号","clearable":true},model:{value:(_vm.searchForm.id),callback:function ($$v) {_vm.$set(_vm.searchForm, "id", $$v)},expression:"searchForm.id"}}),_vm._v(" "),_c('el-input',{staticClass:"handle-input-200 mr10",attrs:{"placeholder":"应用名称","clearable":true},model:{value:(_vm.searchForm.applicationName),callback:function ($$v) {_vm.$set(_vm.searchForm, "applicationName", $$v)},expression:"searchForm.applicationName"}}),_vm._v(" "),_c('el-button',{attrs:{"type":"primary","icon":"search"},on:{"click":_vm.search}},[_vm._v("搜索")])],1),_vm._v(" "),_c('div',{staticClass:"data-table"},[_c('el-table',{ref:"multipleTable",staticClass:"table",attrs:{"data":_vm.tableData,"border":"","header-cell-style":_vm.getRowClass},on:{"selection-change":_vm.handleSelectionChange}},[_c('el-table-column',{attrs:{"type":"selection","width":"55","align":"center"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"serverId","label":"服务器编号","width":"100"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"serverAddress","label":"服务器IP","width":"120"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"applicationName","label":"应用名称","width":"200"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"id","label":"应用编号","width":"80"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"version","label":"应用版本","width":"80"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"status","label":"状态","width":"80","formatter":_vm.formatterStatus}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"configFileName","label":"配置文件路径","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"createTime","label":"创建时间","formatter":_vm.formatterDate}})],1),_vm._v(" "),_c('div',{staticClass:"pagination"},[_c('el-pagination',{attrs:{"background":"","layout":"prev, pager, next","prev-text":"上一页","next-text":"下一页","page-size":_vm.pageSize,"current-page":_vm.currentPage,"total":_vm.totalSize},on:{"current-change":_vm.handleCurrentChange}})],1)],1)]),_vm._v(" "),_c('el-dialog',{attrs:{"title":"编辑应用信息","visible":_vm.editVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.editVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"rules":_vm.rules,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"服务器IP"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"filterable":"","placeholder":"服务器IP","disabled":true},model:{value:(_vm.form.serverAddress),callback:function ($$v) {_vm.$set(_vm.form, "serverAddress", $$v)},expression:"form.serverAddress"}},_vm._l((_vm.serverOptions),function(item){return _c('el-option',{key:item.serverAddress,attrs:{"label":item.serverAddress,"value":item.serverAddress}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"服务器编号"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"服务器编号...","disabled":true},model:{value:(_vm.form.serverId),callback:function ($$v) {_vm.$set(_vm.form, "serverId", _vm._n($$v))},expression:"form.serverId"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"应用名称"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"disabled":true},model:{value:(_vm.form.applicationName),callback:function ($$v) {_vm.$set(_vm.form, "applicationName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.applicationName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"应用版本"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"disabled":true},model:{value:(_vm.form.version),callback:function ($$v) {_vm.$set(_vm.form, "version", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.version"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"状态"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"placeholder":"运行状态..."},model:{value:(_vm.form.status),callback:function ($$v) {_vm.$set(_vm.form, "status", $$v)},expression:"form.status"}},_vm._l((_vm.statuOptions),function(item){return _c('el-option',{key:item.status,attrs:{"label":item.label,"value":item.status}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"配置文件路径"}},[_c('el-input',{staticStyle:{"width":"200px"},model:{value:(_vm.form.configFileName),callback:function ($$v) {_vm.$set(_vm.form, "configFileName", _vm._n($$v))},expression:"form.configFileName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"配置模板"}},[_c('el-input',{attrs:{"type":"textarea","autosize":{ minRows: 10, maxRows: 20},"placeholder":"配置模板内容...","resize":"none"},model:{value:(_vm.form.configTemplate),callback:function ($$v) {_vm.$set(_vm.form, "configTemplate", $$v)},expression:"form.configTemplate"}})],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.editVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveEdit}},[_vm._v("确 定")])],1)],1),_vm._v(" "),_c('el-dialog',{attrs:{"title":"创建应用信息","visible":_vm.createVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.createVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"rules":_vm.rules,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"服务器IP"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"filterable":"","placeholder":"服务器"},on:{"change":_vm.handleSeclectServer},model:{value:(_vm.form.serverAddress),callback:function ($$v) {_vm.$set(_vm.form, "serverAddress", $$v)},expression:"form.serverAddress"}},_vm._l((_vm.serverOptions),function(item){return _c('el-option',{key:item.serverAddress,attrs:{"label":item.serverAddress,"value":item.serverAddress}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"服务器编号"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"disabled":true},model:{value:(_vm.form.serverId),callback:function ($$v) {_vm.$set(_vm.form, "serverId", _vm._n($$v))},expression:"form.serverId"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"应用名称"}},[_c('el-input',{staticStyle:{"width":"200px"},model:{value:(_vm.form.applicationName),callback:function ($$v) {_vm.$set(_vm.form, "applicationName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.applicationName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"应用版本"}},[_c('el-input',{staticStyle:{"width":"200px"},model:{value:(_vm.form.version),callback:function ($$v) {_vm.$set(_vm.form, "version", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.version"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"状态"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"placeholder":"运行状态..."},model:{value:(_vm.form.status),callback:function ($$v) {_vm.$set(_vm.form, "status", $$v)},expression:"form.status"}},_vm._l((_vm.statuOptions),function(item){return _c('el-option',{key:item.status,attrs:{"label":item.label,"value":item.status}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"配置文件路径"}},[_c('el-input',{staticStyle:{"width":"200px"},model:{value:(_vm.form.configFileName),callback:function ($$v) {_vm.$set(_vm.form, "configFileName", _vm._n($$v))},expression:"form.configFileName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"配置模板"}},[_c('el-input',{attrs:{"type":"textarea","autosize":{ minRows: 10, maxRows: 20},"placeholder":"配置模板内容...","resize":"none"},model:{value:(_vm.form.configTemplate),callback:function ($$v) {_vm.$set(_vm.form, "configTemplate", $$v)},expression:"form.configTemplate"}})],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.createVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveCreate}},[_vm._v("确 定")])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_AppManage = (esExports);
// CONCATENATED MODULE: ./src/components/page/AppManage.vue
function injectStyle (ssrContext) {
  __webpack_require__("Ymtc")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-5d3b70e4"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  AppManage,
  page_AppManage,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_AppManage = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "Ymtc":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })

});