webpackJsonp([8],{

/***/ "P+Gp":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "eXr0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/is.js
var is = __webpack_require__("g4PW");
var is_default = /*#__PURE__*/__webpack_require__.n(is);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/OrgManage.vue

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _orgManageTableThis = null;
/* harmony default export */ var OrgManage = ({
    name: 'orgManageTable',
    beforeCreate: function beforeCreate() {
        _orgManageTableThis = this; //将当前组件this赋值给_this对象
    },
    data: function data() {
        return {
            isHospital: true,
            isRadiomics: false,
            isDeep: false,
            isCta: false,
            createCollapse: ['1'],
            editCollapse: ['1'],
            tableData: [],
            currentPage: 0,
            pageSize: 20,
            totalSize: 0,
            multipleSelection: [],
            createVisible: false,
            editVisible: false,
            form: {
                id: '',
                orgId: '',
                orgName: '',
                orgType: '',
                orgInputId: '',
                ossAccessKeyId: '',
                ossAccessKeySecret: '',
                ossAccessKeyIdInner: '',
                ossAccessKeySecretInner: '',
                ossEndPointInner: '',
                ossEndPointOut: '',
                storageBasePath: '',
                ossBucketName: '',
                useSeriesNumberSplit: '',
                modalityMerge: '',
                createCheckInfo: '',
                smsSwitch: '',
                qrSwitch: '',
                webNoticeTag: '',
                webNoticeUrl: '',
                smsToPatientTag: '',
                useMini: '',
                notifyPhone1: '',
                notifyUser1: '',
                tagMapping: '',
                updateCheckInfoSwitch: '',
                defaultSpecificCharacterSet: '',
                createTime: '',
                updateTime: ''
            },
            searchForm: {
                orgType: '',
                orgName: ''
            },
            orgTypeOptions: [{
                id: '1',
                name: '医院'
            }, {
                id: '2',
                name: '组学'
            }, {
                id: '3',
                name: '深度学习'
            }, {
                id: '4',
                name: 'CTA'
            }],
            orgOptions: []
        };
    },
    created: function created() {
        _orgManageTableThis.getData();
    },

    methods: {
        // 分页导航
        handleCurrentChange: function handleCurrentChange(val) {
            _orgManageTableThis.currentPage = val - 1;
            _orgManageTableThis.getData();
        },
        getData: function getData() {
            if (!_orgManageTableThis.currentPage) {
                _orgManageTableThis.currentPage = 0;
            }
            if (!_orgManageTableThis.pageSize) {
                _orgManageTableThis.pageSize = 20;
            }
            this.$axios.post(this.BASE_URLD + '/orgManagement/query', _orgManageTableThis.searchForm).then(function (response) {
                _orgManageTableThis.tableData = response.data.returnData;
                _orgManageTableThis.pageSize = response.data.pageSize;
                _orgManageTableThis.currentPage = response.data.currentPage + 1;
                _orgManageTableThis.totalSize = response.data.totalSize;
            });
        },
        search: function search() {
            _orgManageTableThis.currentPage = 0;
            _orgManageTableThis.getData();
        },
        formatterOrgType: function formatterOrgType(row, column) {
            var orgTypeName = '';
            _orgManageTableThis.orgTypeOptions.forEach(function (item) {
                if (item.id == row.orgType) {
                    orgTypeName = item.name;
                    return;
                }
            });
            return orgTypeName;
        },

        //格式化日期
        formatterDate: function formatterDate(row, column) {
            return this.$moment(row.createTime).format('YYYY-MM-DD HH:mm:ss');
        },
        handleOperate: function handleOperate(command) {
            if (is_default()('createOrg', command)) {
                _orgManageTableThis.handleCreateOrg();
                return;
            }
            if (is_default()('editOrg', command)) {
                _orgManageTableThis.handleEditOrg();
                return;
            }
            if (is_default()('pushOrg', command)) {
                _orgManageTableThis.handlePushOrg();
                return;
            }
        },
        handleCreateOrg: function handleCreateOrg() {
            _orgManageTableThis.form = {
                id: '',
                orgId: '',
                orgName: '',
                orgType: '1',
                orgInputId: '',
                ossAccessKeyId: '',
                ossAccessKeySecret: '',
                ossAccessKeyIdInner: '',
                ossAccessKeySecretInner: '',
                ossEndPointInner: '',
                ossEndPointOut: '',
                storageBasePath: '',
                ossBucketName: '',
                useSeriesNumberSplit: '0',
                modalityMerge: '0',
                createCheckInfo: '0',
                smsSwitch: '0',
                qrSwitch: '0',
                webNoticeTag: '0',
                webNoticeUrl: '',
                smsToPatientTag: '0',
                useMini: '0',
                notifyPhone1: '',
                notifyUser1: '',
                tagMapping: '',
                updateCheckInfoSwitch: '0',
                defaultSpecificCharacterSet: '',
                createTime: '',
                updateTime: ''
            };
            _orgManageTableThis.createCollapse = ['1'];
            _orgManageTableThis.editCollapse = ['1'];
            _orgManageTableThis.isHospital = true;
            _orgManageTableThis.isRadiomics = false;
            _orgManageTableThis.isCta = false;
            _orgManageTableThis.isDeep = false;
            _orgManageTableThis.createVisible = true;
        },
        handleEditOrg: function handleEditOrg() {
            if (_orgManageTableThis.multipleSelection.length > 1) {
                _orgManageTableThis.$message.error('编辑失败！最多选择一行。');
                return;
            }
            if (_orgManageTableThis.multipleSelection.length <= 0 || !_orgManageTableThis.multipleSelection) {
                _orgManageTableThis.$message.error('编辑失败！至少选择一行。');
                return;
            }
            var item = _orgManageTableThis.multipleSelection[0];
            _orgManageTableThis.form = {
                id: item.id,
                orgId: item.orgId,
                orgName: item.orgName,
                orgType: item.orgType,
                orgInputId: item.orgInputId,
                createTime: item.createTime,
                updateTime: item.updateTime,
                ossAccessKeyId: item.ossAccessKeyId,
                ossAccessKeySecret: item.ossAccessKeySecret,
                ossAccessKeyIdInner: item.ossAccessKeyIdInner,
                ossAccessKeySecretInner: item.ossAccessKeySecretInner,
                ossEndPointInner: item.ossEndPointInner,
                ossEndPointOut: item.ossEndPointOut,
                storageBasePath: item.storageBasePath,
                ossBucketName: item.ossBucketName,
                useSeriesNumberSplit: item.useSeriesNumberSplit,
                modalityMerge: item.modalityMerge,
                createCheckInfo: item.createCheckInfo,
                smsSwitch: item.smsSwitch,
                qrSwitch: item.qrSwitch,
                webNoticeTag: item.webNoticeTag,
                webNoticeUrl: item.webNoticeUrl,
                smsToPatientTag: item.smsToPatientTag,
                useMini: item.useMini,
                notifyPhone1: item.notifyPhone1,
                notifyUser1: item.notifyUser1,
                tagMapping: item.tagMapping,
                updateCheckInfoSwitch: item.updateCheckInfoSwitch,
                defaultSpecificCharacterSet: item.defaultSpecificCharacterSet
            };
            _orgManageTableThis.createCollapse = ['1'];
            _orgManageTableThis.editCollapse = ['1'];
            if (item.orgType == '1') {
                _orgManageTableThis.isHospital = true;
                _orgManageTableThis.isRadiomics = false;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isCta = false;
            } else if (item.orgType == '2') {
                _orgManageTableThis.isRadiomics = true;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isCta = false;
            } else if (item.orgType == '3') {
                _orgManageTableThis.isDeep = true;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isRadiomics = false;
                _orgManageTableThis.isCta = false;
            } else if (item.orgType == '4') {
                _orgManageTableThis.isCta = true;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isRadiomics = false;
            }
            _orgManageTableThis.editVisible = true;
        },
        handleSelectionChange: function handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        saveCreate: function saveCreate() {
            if (!_orgManageTableThis.form.orgName || is_default()('', _orgManageTableThis.form.orgName)) {
                _orgManageTableThis.$message.error('创建失败！机构名称不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.orgType || is_default()('', _orgManageTableThis.form.orgType)) {
                _orgManageTableThis.$message.error('创建失败！机构类型不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeyIdInner || is_default()('', _orgManageTableThis.form.ossAccessKeyIdInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网权限认证id不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeySecretInner || is_default()('', _orgManageTableThis.form.ossAccessKeySecretInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网权限认证Secret不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossEndPointInner || is_default()('', _orgManageTableThis.form.ossEndPointInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网地址不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeyId || is_default()('', _orgManageTableThis.form.ossAccessKeyId)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网权限认证id不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeySecret || is_default()('', _orgManageTableThis.form.ossAccessKeySecret)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网权限认证Secret不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossEndPointOut || is_default()('', _orgManageTableThis.form.ossEndPointOut)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网地址不能为空。');
                return;
            }
            if (is_default()('2', _orgManageTableThis.form.orgType) || is_default()('3', _orgManageTableThis.form.orgType)) {
                if (is_default()('1', _orgManageTableThis.form.webNoticeTag && is_default()('', _orgManageTableThis.form.webNoticeUrl))) {
                    _orgManageTableThis.$message.error('创建失败！Web通知地址不能为空。');
                    return;
                }
            }
            if (!_orgManageTableThis.form.ossBucketName || is_default()('', _orgManageTableThis.form.ossBucketName)) {
                _orgManageTableThis.$message.error('创建失败！云存储空间不能为空。');
                return;
            }
            this.$axios.post(this.BASE_URLD + '/orgManagement/create', _orgManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _orgManageTableThis.$message.success('机构创建成功。');
                    _orgManageTableThis.createVisible = false;

                    _orgManageTableThis.currentPage = 0;
                    _orgManageTableThis.getData();
                } else {
                    _orgManageTableThis.$message.error('创建失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _orgManageTableThis.$message.error("创建失败！服务器异常，请联系管理员。");
            });
        },

        // 保存编辑
        saveEdit: function saveEdit() {
            if (!_orgManageTableThis.form.orgName || is_default()('', _orgManageTableThis.form.orgName)) {
                _orgManageTableThis.$message.error('创建失败！机构名称不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.orgType || is_default()('', _orgManageTableThis.form.orgType)) {
                _orgManageTableThis.$message.error('创建失败！机构类型不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeyIdInner || is_default()('', _orgManageTableThis.form.ossAccessKeyIdInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网权限认证id不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeySecretInner || is_default()('', _orgManageTableThis.form.ossAccessKeySecretInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网权限认证Secret不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossEndPointInner || is_default()('', _orgManageTableThis.form.ossEndPointInner)) {
                _orgManageTableThis.$message.error('创建失败！OSS内网地址不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeyId || is_default()('', _orgManageTableThis.form.ossAccessKeyId)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网权限认证id不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossAccessKeySecret || is_default()('', _orgManageTableThis.form.ossAccessKeySecret)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网权限认证Secret不能为空。');
                return;
            }
            if (!_orgManageTableThis.form.ossEndPointOut || is_default()('', _orgManageTableThis.form.ossEndPointOut)) {
                _orgManageTableThis.$message.error('创建失败！OSS公网地址不能为空。');
                return;
            }
            if (is_default()('2', _orgManageTableThis.form.orgType) || is_default()('3', _orgManageTableThis.form.orgType)) {
                if (is_default()('1', _orgManageTableThis.form.webNoticeTag && is_default()('', _orgManageTableThis.form.webNoticeUrl))) {
                    _orgManageTableThis.$message.error('创建失败！Web通知地址不能为空。');
                    return;
                }
            }
            if (!_orgManageTableThis.form.ossBucketName || is_default()('', _orgManageTableThis.form.ossBucketName)) {
                _orgManageTableThis.$message.error('创建失败！云存储空间不能为空。');
                return;
            }
            this.$axios.post(this.BASE_URLD + '/orgManagement/update', _orgManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _orgManageTableThis.$message.success('机构更新成功。');
                    _orgManageTableThis.editVisible = false;

                    _orgManageTableThis.currentPage = 0;
                    _orgManageTableThis.getData();
                } else {
                    _orgManageTableThis.$message.error('更新失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _orgManageTableThis.$message.error("更新失败！服务器异常，请联系管理员。");
            });
        },
        handlePushOrg: function handlePushOrg() {
            var _this = this;

            if (_orgManageTableThis.multipleSelection.length <= 0 || !_orgManageTableThis.multipleSelection) {
                _orgManageTableThis.$message.error('启动失败！至少选择一行。');
                return;
            }
            var idxCnt = _orgManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _orgManageTableThis.multipleSelection[idx];
                _orgManageTableThis.form = {
                    id: item.id,
                    orgName: item.orgName
                };
                this.$axios.post(this.BASE_URLD + '/orgManagement/push', _orgManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _orgManageTableThis.$message.success('机构信息推送成功。');
                    } else {
                        _this.$alert('推送失败！' + response.data.returnMessage + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('推送失败！服务器异常，请联系管理员' + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        getRowClass: function getRowClass(_ref) {
            var row = _ref.row,
                column = _ref.column,
                rowIndex = _ref.rowIndex,
                columnIndex = _ref.columnIndex;

            if (rowIndex == 0) {
                return 'background:#EFEFEF';
            } else {
                return '';
            }
        },
        handleSelectOrgType: function handleSelectOrgType(id) {
            if (id == '1') {
                _orgManageTableThis.isHospital = true;
                _orgManageTableThis.isRadiomics = false;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isCta = false;
            } else if (id == '2') {
                _orgManageTableThis.isRadiomics = true;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isCta = false;
            } else if (id == '3') {
                _orgManageTableThis.isDeep = true;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isRadiomics = false;
                _orgManageTableThis.isCta = false;
            } else if (id == '4') {
                _orgManageTableThis.isCta = true;
                _orgManageTableThis.isDeep = false;
                _orgManageTableThis.isHospital = false;
                _orgManageTableThis.isRadiomics = false;
            }
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-25fe09ec","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/OrgManage.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"table"},[_c('div',{staticClass:"crumbs"},[_c('el-breadcrumb',{attrs:{"separator":"/"}},[_c('el-breadcrumb-item',[_c('i',{staticClass:"el-icon-hy-jigouguanli"}),_vm._v(" 机构管理")])],1)],1),_vm._v(" "),_c('div',{staticClass:"container"},[_c('div',{staticClass:"handle-box"},[_c('el-dropdown',{on:{"command":_vm.handleOperate}},[_c('el-button',{attrs:{"size":"mini","type":"primary"}},[_c('i',{staticClass:"el-icon-hy-caozuo-shezhi",staticStyle:{"font-size":"10px !important"}}),_vm._v("  操 作\n                ")]),_vm._v(" "),_c('el-dropdown-menu',{attrs:{"slot":"dropdown","size":"small"},slot:"dropdown"},[_c('el-dropdown-item',{attrs:{"command":"createOrg"}},[_vm._v("新增")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"editOrg"}},[_vm._v("编辑")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"pushOrg"}},[_vm._v("推送")])],1)],1),_vm._v(" "),_c('el-select',{staticStyle:{"width":"150px"},attrs:{"filterable":"","placeholder":"机构类型","clearable":true},model:{value:(_vm.searchForm.orgType),callback:function ($$v) {_vm.$set(_vm.searchForm, "orgType", $$v)},expression:"searchForm.orgType"}},_vm._l((_vm.orgTypeOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.name,"value":item.id}})}),1),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"机构名称","clearable":true},model:{value:(_vm.searchForm.orgName),callback:function ($$v) {_vm.$set(_vm.searchForm, "orgName", $$v)},expression:"searchForm.orgName"}}),_vm._v(" "),_c('el-button',{attrs:{"type":"primary","icon":"search"},on:{"click":_vm.search}},[_vm._v("搜索")])],1),_vm._v(" "),_c('div',{staticClass:"data-table"},[_c('el-table',{ref:"multipleTable",staticClass:"table",attrs:{"data":_vm.tableData,"border":"","header-cell-style":_vm.getRowClass},on:{"selection-change":_vm.handleSelectionChange}},[_c('el-table-column',{attrs:{"type":"selection","width":"55","align":"center"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"orgId","label":"机构编号","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"orgInputId","label":"机构入库编号","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"orgName","label":"机构名称","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"orgType","label":"机构类型","width":"180","formatter":_vm.formatterOrgType}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"createTime","label":"创建时间","formatter":_vm.formatterDate,"width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"updateTime","label":"更新时间","formatter":_vm.formatterDate}})],1),_vm._v(" "),_c('div',{staticClass:"pagination"},[_c('el-pagination',{attrs:{"background":"","layout":"prev, pager, next","prev-text":"上一页","next-text":"下一页","page-size":_vm.pageSize,"current-page":_vm.currentPage,"total":_vm.totalSize},on:{"current-change":_vm.handleCurrentChange}})],1)],1)]),_vm._v(" "),_c('el-dialog',{attrs:{"title":"新增","visible":_vm.createVisible,"close-on-click-modal":false,"width":"40%"},on:{"update:visible":function($event){_vm.createVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"label-width":"40%"}},[_c('el-collapse',{model:{value:(_vm.createCollapse),callback:function ($$v) {_vm.createCollapse=$$v},expression:"createCollapse"}},[_c('el-collapse-item',{attrs:{"title":"基本信息","name":"1"}},[_c('el-form-item',{attrs:{"label":"机构名称"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"机构名称"},model:{value:(_vm.form.orgName),callback:function ($$v) {_vm.$set(_vm.form, "orgName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.orgName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"机构类型"}},[_c('el-select',{staticStyle:{"width":"240px"},attrs:{"filterable":"","placeholder":"机构类型"},on:{"change":_vm.handleSelectOrgType},model:{value:(_vm.form.orgType),callback:function ($$v) {_vm.$set(_vm.form, "orgType", $$v)},expression:"form.orgType"}},_vm._l((_vm.orgTypeOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.name,"value":item.id}})}),1)],1)],1),_vm._v(" "),_c('el-collapse-item',{attrs:{"title":"配置信息","name":"2"}},[_c('el-form-item',{attrs:{"label":"OSS内网地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网地址"},model:{value:(_vm.form.ossEndPointInner),callback:function ($$v) {_vm.$set(_vm.form, "ossEndPointInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossEndPointInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS内网权限认证id"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网权限认证id"},model:{value:(_vm.form.ossAccessKeyIdInner),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeyIdInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeyIdInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS内网权限认证Secret"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网权限认证Secret"},model:{value:(_vm.form.ossAccessKeySecretInner),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeySecretInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeySecretInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网地址"},model:{value:(_vm.form.ossEndPointOut),callback:function ($$v) {_vm.$set(_vm.form, "ossEndPointOut", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossEndPointOut"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网权限认证id"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网权限认证id"},model:{value:(_vm.form.ossAccessKeyId),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeyId", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeyId"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网权限认证Secret"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网权限认证Secret"},model:{value:(_vm.form.ossAccessKeySecret),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeySecret", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeySecret"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isRadiomics||_vm.isDeep),expression:"isRadiomics||isDeep"}],attrs:{"label":"云存储路径前缀"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"云存储路径前缀"},model:{value:(_vm.form.storageBasePath),callback:function ($$v) {_vm.$set(_vm.form, "storageBasePath", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.storageBasePath"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"云存储空间"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"云存储空间"},model:{value:(_vm.form.ossBucketName),callback:function ($$v) {_vm.$set(_vm.form, "ossBucketName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossBucketName"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isRadiomics||_vm.isDeep),expression:"isRadiomics||isDeep"}],attrs:{"label":"web通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.webNoticeTag),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeTag", $$v)},expression:"form.webNoticeTag"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.webNoticeTag),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeTag", $$v)},expression:"form.webNoticeTag"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:((_vm.isRadiomics||_vm.isDeep)&&_vm.form.webNoticeTag=='1'),expression:"(isRadiomics||isDeep)&&form.webNoticeTag=='1'"}],attrs:{"label":"web通知地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"web通知地址"},model:{value:(_vm.form.webNoticeUrl),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeUrl", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.webNoticeUrl"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"是否使用迷你版报告"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.useMini),callback:function ($$v) {_vm.$set(_vm.form, "useMini", $$v)},expression:"form.useMini"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.useMini),callback:function ($$v) {_vm.$set(_vm.form, "useMini", $$v)},expression:"form.useMini"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"短信通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.smsToPatientTag),callback:function ($$v) {_vm.$set(_vm.form, "smsToPatientTag", $$v)},expression:"form.smsToPatientTag"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.smsToPatientTag),callback:function ($$v) {_vm.$set(_vm.form, "smsToPatientTag", $$v)},expression:"form.smsToPatientTag"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"二维码通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.qrSwitch),callback:function ($$v) {_vm.$set(_vm.form, "qrSwitch", $$v)},expression:"form.qrSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.qrSwitch),callback:function ($$v) {_vm.$set(_vm.form, "qrSwitch", $$v)},expression:"form.qrSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"运维联系人"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"运维联系人"},model:{value:(_vm.form.notifyUser1),callback:function ($$v) {_vm.$set(_vm.form, "notifyUser1", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.notifyUser1"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"运维联系人电话"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"运维联系人电话"},model:{value:(_vm.form.notifyPhone1),callback:function ($$v) {_vm.$set(_vm.form, "notifyPhone1", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.notifyPhone1"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isDeep||_vm.isRadiomics),expression:"isDeep||isRadiomics"}],attrs:{"label":"modality合并开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.modalityMerge),callback:function ($$v) {_vm.$set(_vm.form, "modalityMerge", $$v)},expression:"form.modalityMerge"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.modalityMerge),callback:function ($$v) {_vm.$set(_vm.form, "modalityMerge", $$v)},expression:"form.modalityMerge"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"RIS数据生成开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.createCheckInfo),callback:function ($$v) {_vm.$set(_vm.form, "createCheckInfo", $$v)},expression:"form.createCheckInfo"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.createCheckInfo),callback:function ($$v) {_vm.$set(_vm.form, "createCheckInfo", $$v)},expression:"form.createCheckInfo"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isDeep||_vm.isRadiomics),expression:"isDeep||isRadiomics"}],attrs:{"label":"使用seriesNumber将series拆分"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.useSeriesNumberSplit),callback:function ($$v) {_vm.$set(_vm.form, "useSeriesNumberSplit", $$v)},expression:"form.useSeriesNumberSplit"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.useSeriesNumberSplit),callback:function ($$v) {_vm.$set(_vm.form, "useSeriesNumberSplit", $$v)},expression:"form.useSeriesNumberSplit"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"短信告警开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.smsSwitch),callback:function ($$v) {_vm.$set(_vm.form, "smsSwitch", $$v)},expression:"form.smsSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.smsSwitch),callback:function ($$v) {_vm.$set(_vm.form, "smsSwitch", $$v)},expression:"form.smsSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"更新检查开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.updateCheckInfoSwitch),callback:function ($$v) {_vm.$set(_vm.form, "updateCheckInfoSwitch", $$v)},expression:"form.updateCheckInfoSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.updateCheckInfoSwitch),callback:function ($$v) {_vm.$set(_vm.form, "updateCheckInfoSwitch", $$v)},expression:"form.updateCheckInfoSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"默认字符集"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"默认字符集"},model:{value:(_vm.form.defaultSpecificCharacterSet),callback:function ($$v) {_vm.$set(_vm.form, "defaultSpecificCharacterSet", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.defaultSpecificCharacterSet"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"Tag映射关系"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"type":"textarea","placeholder":"Tag映射关系","rows":"3"},model:{value:(_vm.form.tagMapping),callback:function ($$v) {_vm.$set(_vm.form, "tagMapping", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.tagMapping"}})],1)],1)],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.createVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveCreate}},[_vm._v("确 定")])],1)],1),_vm._v(" "),_c('el-dialog',{attrs:{"title":"编辑","visible":_vm.editVisible,"close-on-click-modal":false,"width":"40%"},on:{"update:visible":function($event){_vm.editVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"label-width":"40%"}},[_c('el-collapse',{model:{value:(_vm.editCollapse),callback:function ($$v) {_vm.editCollapse=$$v},expression:"editCollapse"}},[_c('el-collapse-item',{attrs:{"title":"基本信息","name":"1"}},[_c('el-form-item',{attrs:{"label":"机构名称"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"机构名称"},model:{value:(_vm.form.orgName),callback:function ($$v) {_vm.$set(_vm.form, "orgName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.orgName"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"机构类型"}},[_c('el-select',{staticStyle:{"width":"240px"},attrs:{"filterable":"","placeholder":"机构类型"},on:{"change":_vm.handleSelectOrgType},model:{value:(_vm.form.orgType),callback:function ($$v) {_vm.$set(_vm.form, "orgType", $$v)},expression:"form.orgType"}},_vm._l((_vm.orgTypeOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.name,"value":item.id}})}),1)],1)],1),_vm._v(" "),_c('el-collapse-item',{attrs:{"title":"配置信息","name":"2"}},[_c('el-form-item',{attrs:{"label":"OSS内网地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网地址"},model:{value:(_vm.form.ossEndPointInner),callback:function ($$v) {_vm.$set(_vm.form, "ossEndPointInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossEndPointInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS内网权限认证id"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网权限认证id"},model:{value:(_vm.form.ossAccessKeyIdInner),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeyIdInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeyIdInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS内网权限认证Secret"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS内网权限认证Secret"},model:{value:(_vm.form.ossAccessKeySecretInner),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeySecretInner", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeySecretInner"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网地址"},model:{value:(_vm.form.ossEndPointOut),callback:function ($$v) {_vm.$set(_vm.form, "ossEndPointOut", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossEndPointOut"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网权限认证id"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网权限认证id"},model:{value:(_vm.form.ossAccessKeyId),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeyId", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeyId"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"OSS公网权限认证Secret"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"OSS公网权限认证Secret"},model:{value:(_vm.form.ossAccessKeySecret),callback:function ($$v) {_vm.$set(_vm.form, "ossAccessKeySecret", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossAccessKeySecret"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isRadiomics||_vm.isDeep),expression:"isRadiomics||isDeep"}],attrs:{"label":"云存储路径前缀"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"云存储路径前缀"},model:{value:(_vm.form.storageBasePath),callback:function ($$v) {_vm.$set(_vm.form, "storageBasePath", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.storageBasePath"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"云存储空间"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"云存储空间"},model:{value:(_vm.form.ossBucketName),callback:function ($$v) {_vm.$set(_vm.form, "ossBucketName", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.ossBucketName"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isRadiomics||_vm.isDeep),expression:"isRadiomics||isDeep"}],attrs:{"label":"web通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.webNoticeTag),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeTag", $$v)},expression:"form.webNoticeTag"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.webNoticeTag),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeTag", $$v)},expression:"form.webNoticeTag"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:((_vm.isRadiomics||_vm.isDeep)&&_vm.form.webNoticeTag=='1'),expression:"(isRadiomics||isDeep)&&form.webNoticeTag=='1'"}],attrs:{"label":"web通知地址"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"web通知地址"},model:{value:(_vm.form.webNoticeUrl),callback:function ($$v) {_vm.$set(_vm.form, "webNoticeUrl", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.webNoticeUrl"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"是否使用迷你版报告"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.useMini),callback:function ($$v) {_vm.$set(_vm.form, "useMini", $$v)},expression:"form.useMini"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.useMini),callback:function ($$v) {_vm.$set(_vm.form, "useMini", $$v)},expression:"form.useMini"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"短信通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.smsToPatientTag),callback:function ($$v) {_vm.$set(_vm.form, "smsToPatientTag", $$v)},expression:"form.smsToPatientTag"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.smsToPatientTag),callback:function ($$v) {_vm.$set(_vm.form, "smsToPatientTag", $$v)},expression:"form.smsToPatientTag"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"二维码通知"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.qrSwitch),callback:function ($$v) {_vm.$set(_vm.form, "qrSwitch", $$v)},expression:"form.qrSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.qrSwitch),callback:function ($$v) {_vm.$set(_vm.form, "qrSwitch", $$v)},expression:"form.qrSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"运维联系人"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"运维联系人"},model:{value:(_vm.form.notifyUser1),callback:function ($$v) {_vm.$set(_vm.form, "notifyUser1", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.notifyUser1"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"运维联系人电话"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"运维联系人电话"},model:{value:(_vm.form.notifyPhone1),callback:function ($$v) {_vm.$set(_vm.form, "notifyPhone1", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.notifyPhone1"}})],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isDeep||_vm.isRadiomics),expression:"isDeep||isRadiomics"}],attrs:{"label":"modality合并开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.modalityMerge),callback:function ($$v) {_vm.$set(_vm.form, "modalityMerge", $$v)},expression:"form.modalityMerge"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.modalityMerge),callback:function ($$v) {_vm.$set(_vm.form, "modalityMerge", $$v)},expression:"form.modalityMerge"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"RIS数据生成开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.createCheckInfo),callback:function ($$v) {_vm.$set(_vm.form, "createCheckInfo", $$v)},expression:"form.createCheckInfo"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.createCheckInfo),callback:function ($$v) {_vm.$set(_vm.form, "createCheckInfo", $$v)},expression:"form.createCheckInfo"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isDeep||_vm.isRadiomics),expression:"isDeep||isRadiomics"}],attrs:{"label":"使用seriesNumber将series拆分"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.useSeriesNumberSplit),callback:function ($$v) {_vm.$set(_vm.form, "useSeriesNumberSplit", $$v)},expression:"form.useSeriesNumberSplit"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.useSeriesNumberSplit),callback:function ($$v) {_vm.$set(_vm.form, "useSeriesNumberSplit", $$v)},expression:"form.useSeriesNumberSplit"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"短信告警开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.smsSwitch),callback:function ($$v) {_vm.$set(_vm.form, "smsSwitch", $$v)},expression:"form.smsSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.smsSwitch),callback:function ($$v) {_vm.$set(_vm.form, "smsSwitch", $$v)},expression:"form.smsSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.isHospital),expression:"isHospital"}],attrs:{"label":"更新检查开关"}},[_c('el-radio',{attrs:{"label":"1"},model:{value:(_vm.form.updateCheckInfoSwitch),callback:function ($$v) {_vm.$set(_vm.form, "updateCheckInfoSwitch", $$v)},expression:"form.updateCheckInfoSwitch"}},[_vm._v("是")]),_vm._v(" "),_c('el-radio',{attrs:{"label":"0"},model:{value:(_vm.form.updateCheckInfoSwitch),callback:function ($$v) {_vm.$set(_vm.form, "updateCheckInfoSwitch", $$v)},expression:"form.updateCheckInfoSwitch"}},[_vm._v("否")])],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"默认字符集"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"placeholder":"默认字符集"},model:{value:(_vm.form.defaultSpecificCharacterSet),callback:function ($$v) {_vm.$set(_vm.form, "defaultSpecificCharacterSet", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.defaultSpecificCharacterSet"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"Tag映射关系"}},[_c('el-input',{staticStyle:{"width":"240px"},attrs:{"type":"textarea","placeholder":"Tag映射关系","rows":"3"},model:{value:(_vm.form.tagMapping),callback:function ($$v) {_vm.$set(_vm.form, "tagMapping", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.tagMapping"}})],1)],1)],1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.editVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveEdit}},[_vm._v("确 定")])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_OrgManage = (esExports);
// CONCATENATED MODULE: ./src/components/page/OrgManage.vue
function injectStyle (ssrContext) {
  __webpack_require__("P+Gp")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-25fe09ec"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  OrgManage,
  page_OrgManage,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_OrgManage = __webpack_exports__["default"] = (Component.exports);


/***/ })

});