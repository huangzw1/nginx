webpackJsonp([3],{

/***/ "XYik":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "ntvM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/is.js
var is = __webpack_require__("g4PW");
var is_default = /*#__PURE__*/__webpack_require__.n(is);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/UserManage.vue

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _userManageTableThis = null;
/* harmony default export */ var UserManage = ({
    name: 'orgManageTable',
    beforeCreate: function beforeCreate() {
        _userManageTableThis = this; //将当前组件this赋值给_this对象
    },
    data: function data() {
        return {
            tableData: [],
            currentPage: 0,
            pageSize: 20,
            totalSize: 0,
            multipleSelection: [],
            createVisible: false,
            editVisible: false,
            form: {
                id: '',
                mobilePhone: '',
                username: '',
                orgId: '',
                orgName: '',
                password: '',
                status: '',
                roleId: [],
                roleName: '',
                createTime: ''
            },
            searchForm: {
                mobilePhone: '',
                username: ''
            },
            orgTypeOptions: [{
                id: '1',
                name: '医院'
            }, {
                id: '2',
                name: '组学'
            }, {
                id: '3',
                name: '深度学习'
            }, {
                id: '4',
                name: 'CTA'
            }],
            orgOptions: [],
            roleOptions: []
        };
    },
    created: function created() {
        _userManageTableThis.getData();
    },

    methods: {
        // 分页导航
        handleCurrentChange: function handleCurrentChange(val) {
            _userManageTableThis.currentPage = val - 1;
            _userManageTableThis.getData();
        },
        getData: function getData() {
            if (!_userManageTableThis.currentPage) {
                _userManageTableThis.currentPage = 0;
            }
            if (!_userManageTableThis.pageSize) {
                _userManageTableThis.pageSize = 20;
            }
            this.$axios.post(this.BASE_URLD + '/userManagement/query', _userManageTableThis.searchForm).then(function (response) {
                _userManageTableThis.tableData = response.data.returnData;
                _userManageTableThis.pageSize = response.data.pageSize;
                _userManageTableThis.currentPage = response.data.currentPage + 1;
                _userManageTableThis.totalSize = response.data.totalSize;
            });
        },
        search: function search() {
            _userManageTableThis.currentPage = 0;
            _userManageTableThis.getData();
        },
        formatterStatus: function formatterStatus(row, column) {
            var returnStr = "";
            if (is_default()('0', row.status)) {
                returnStr = '未启用';
            }
            if (is_default()('1', row.status)) {
                returnStr = '已启用';
            }
            return returnStr;
        },
        handleOperate: function handleOperate(command) {
            if (is_default()('createUser', command)) {
                _userManageTableThis.handleCreateUser();
                return;
            }
            if (is_default()('editUser', command)) {
                _userManageTableThis.handleEditUser();
                return;
            }
            if (is_default()('enableUser', command)) {
                _userManageTableThis.handleEnableUser();
                return;
            }
            if (is_default()('disableUser', command)) {
                _userManageTableThis.handleDisableUser();
                return;
            }
        },
        handleCreateUser: function handleCreateUser() {
            _userManageTableThis.form = {
                id: '',
                mobilePhone: '',
                username: '',
                orgId: '',
                orgName: '',
                password: '',
                status: '',
                roleId: [],
                roleName: '',
                createTime: ''
            };
            _userManageTableThis.createVisible = true;
            _userManageTableThis.getAllOrgs();
            _userManageTableThis.getAllRoles();
        },
        handleEditUser: function handleEditUser() {
            if (_userManageTableThis.multipleSelection.length > 1) {
                _userManageTableThis.$message.error('编辑失败！最多选择一行。');
                return;
            }
            if (_userManageTableThis.multipleSelection.length <= 0 || !_userManageTableThis.multipleSelection) {
                _userManageTableThis.$message.error('编辑失败！至少选择一行。');
                return;
            }
            var item = _userManageTableThis.multipleSelection[0];
            _userManageTableThis.form = {
                id: item.id,
                mobilePhone: item.mobilePhone,
                username: item.username,
                orgId: item.orgId,
                orgName: item.orgName,
                password: item.password,
                status: item.status,
                roleId: item.roleId,
                roleName: item.roleName,
                createTime: item.createTime
            };
            _userManageTableThis.editVisible = true;
            _userManageTableThis.getAllOrgs();
            _userManageTableThis.getAllRoles();
        },
        handleSelectionChange: function handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        getAllRoles: function getAllRoles() {
            this.$axios.post(this.BASE_URLD + '/userManagement/getAllRoles', '').then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _userManageTableThis.roleOptions = response.data.returnData;
                }
            });
        },
        getAllOrgs: function getAllOrgs() {
            this.$axios.post(this.BASE_URLD + '/userManagement/getAllOrgs', '').then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _userManageTableThis.orgOptions = response.data.returnData;
                }
            });
        },
        saveCreate: function saveCreate() {
            if (!_userManageTableThis.form.username || is_default()('', _userManageTableThis.form.username)) {
                _userManageTableThis.$message.error('创建失败！姓名不能为空。');
                return;
            }
            if (!_userManageTableThis.form.mobilePhone || is_default()('', _userManageTableThis.form.mobilePhone)) {
                _userManageTableThis.$message.error('创建失败！手机号不能为空。');
                return;
            }
            if (!_userManageTableThis.form.orgId || is_default()('', _userManageTableThis.form.orgId)) {
                _userManageTableThis.$message.error('创建失败！机构不能为空。');
                return;
            }
            if (!_userManageTableThis.form.password || is_default()('', _userManageTableThis.form.password)) {
                _userManageTableThis.$message.error('创建失败！密码不能为空。');
                return;
            }
            if (!_userManageTableThis.form.roleId || is_default()([], _userManageTableThis.form.roleId)) {
                _userManageTableThis.$message.error('创建失败！角色不能为空。');
                return;
            }
            _userManageTableThis.form.password = this.$md5(_userManageTableThis.form.password);
            this.$axios.post(this.BASE_URLD + '/userManagement/create', _userManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _userManageTableThis.$message.success('用户创建成功。');
                    _userManageTableThis.createVisible = false;

                    _userManageTableThis.currentPage = 0;
                    _userManageTableThis.getData();
                } else {
                    _userManageTableThis.$message.error('创建失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _userManageTableThis.$message.error("创建失败！服务器异常，请联系管理员。");
            });
        },

        // 保存编辑
        saveEdit: function saveEdit() {
            if (!_userManageTableThis.form.username || is_default()('', _userManageTableThis.form.username)) {
                _userManageTableThis.$message.error('更新失败！姓名不能为空。');
                return;
            }
            if (!_userManageTableThis.form.mobilePhone || is_default()('', _userManageTableThis.form.mobilePhone)) {
                _userManageTableThis.$message.error('更新失败！手机号不能为空。');
                return;
            }
            if (!_userManageTableThis.form.orgId || is_default()('', _userManageTableThis.form.orgId)) {
                _userManageTableThis.$message.error('更新失败！机构不能为空。');
                return;
            }
            if (!_userManageTableThis.form.roleId || is_default()([], _userManageTableThis.form.roleId)) {
                _userManageTableThis.$message.error('创建失败！角色不能为空。');
                return;
            }
            this.$axios.post(this.BASE_URLD + '/userManagement/update', _userManageTableThis.form).then(function (response) {
                if (is_default()('rdcc-00000', response.data.returnCode)) {
                    _userManageTableThis.$message.success('用户更新成功。');
                    _userManageTableThis.editVisible = false;

                    _userManageTableThis.currentPage = 0;
                    _userManageTableThis.getData();
                } else {
                    _userManageTableThis.$message.error('更新失败！' + response.data.returnMessage + "。");
                    return;
                }
            }).catch(function (error) {
                if (error.response) {
                    // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error.config);
                _userManageTableThis.$message.error("更新失败！服务器异常，请联系管理员。");
            });
        },
        handleEnableUser: function handleEnableUser() {
            var _this = this;

            if (_userManageTableThis.multipleSelection.length <= 0 || !_userManageTableThis.multipleSelection) {
                _userManageTableThis.$message.error('启用失败！至少选择一行。');
                return;
            }
            var idxCnt = _userManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _userManageTableThis.multipleSelection[idx];
                _userManageTableThis.form = {
                    id: item.id
                };
                this.$axios.post(this.BASE_URLD + '/userManagement/enableUser', _userManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _userManageTableThis.$message.success('用户启用成功。');
                        _userManageTableThis.currentPage = 0;
                        _userManageTableThis.getData();
                    } else {
                        _this.$alert('启用失败！' + response.data.returnMessage + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('启用失败！服务器异常，请联系管理员' + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        handleDisableUser: function handleDisableUser() {
            var _this2 = this;

            if (_userManageTableThis.multipleSelection.length <= 0 || !_userManageTableThis.multipleSelection) {
                _userManageTableThis.$message.error('停用失败！至少选择一行。');
                return;
            }
            var idxCnt = _userManageTableThis.multipleSelection.length;
            for (var idx = 0; idx < idxCnt; idx++) {
                var errorflag = void 0;
                var item = _userManageTableThis.multipleSelection[idx];
                _userManageTableThis.form = {
                    id: item.id
                };
                this.$axios.post(this.BASE_URLD + '/userManagement/disableUser', _userManageTableThis.form).then(function (response) {
                    if (is_default()('rdcc-00000', response.data.returnCode)) {
                        _userManageTableThis.$message.success('用户停用成功。');
                        _userManageTableThis.currentPage = 0;
                        _userManageTableThis.getData();
                    } else {
                        _this2.$alert('停用失败！' + response.data.returnMessage + '。', '错误提示', {
                            confirmButtonText: '确定',
                            callback: function callback(action) {}
                        });
                        errorflag = 1;
                        return;
                    }
                }).catch(function (error) {
                    if (error.response) {
                        // 请求已发出，但服务器响应的状态码不在 2xx 范围内
                        console.log(error.response.data);
                        console.log(error.response.status);
                        console.log(error.response.headers);
                    } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                    console.log(error.config);
                    this.$alert('停用失败！服务器异常，请联系管理员' + '。', '错误提示', {
                        confirmButtonText: '确定',
                        callback: function callback(action) {}
                    });
                    errorflag = 1;
                });
                if (errorflag) {
                    return;
                }
            }
        },
        getRowClass: function getRowClass(_ref) {
            var row = _ref.row,
                column = _ref.column,
                rowIndex = _ref.rowIndex,
                columnIndex = _ref.columnIndex;

            if (rowIndex == 0) {
                return 'background:#EFEFEF';
            } else {
                return '';
            }
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-65cb93a7","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/UserManage.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"table"},[_c('div',{staticClass:"crumbs"},[_c('el-breadcrumb',{attrs:{"separator":"/"}},[_c('el-breadcrumb-item',[_c('i',{staticClass:"el-icon-hy-yonghu"}),_vm._v(" 用户管理")])],1)],1),_vm._v(" "),_c('div',{staticClass:"container"},[_c('div',{staticClass:"handle-box"},[_c('el-dropdown',{on:{"command":_vm.handleOperate}},[_c('el-button',{attrs:{"size":"mini","type":"primary"}},[_c('i',{staticClass:"el-icon-hy-caozuo-shezhi",staticStyle:{"font-size":"10px !important"}}),_vm._v("  操 作\n                ")]),_vm._v(" "),_c('el-dropdown-menu',{attrs:{"slot":"dropdown","size":"small"},slot:"dropdown"},[_c('el-dropdown-item',{attrs:{"command":"createUser"}},[_vm._v("新增")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"editUser"}},[_vm._v("编辑")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"enableUser"}},[_vm._v("启用")]),_vm._v(" "),_c('el-dropdown-item',{attrs:{"command":"disableUser"}},[_vm._v("停用")])],1)],1),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"手机号","clearable":true},model:{value:(_vm.searchForm.mobilePhone),callback:function ($$v) {_vm.$set(_vm.searchForm, "mobilePhone", $$v)},expression:"searchForm.mobilePhone"}}),_vm._v(" "),_c('el-input',{staticClass:"handle-input mr10",attrs:{"placeholder":"姓名","clearable":true},model:{value:(_vm.searchForm.userName),callback:function ($$v) {_vm.$set(_vm.searchForm, "userName", $$v)},expression:"searchForm.userName"}}),_vm._v(" "),_c('el-button',{attrs:{"type":"primary","icon":"search"},on:{"click":_vm.search}},[_vm._v("搜索")])],1),_vm._v(" "),_c('div',{staticClass:"data-table"},[_c('el-table',{ref:"multipleTable",staticClass:"table",attrs:{"data":_vm.tableData,"border":"","header-cell-style":_vm.getRowClass},on:{"selection-change":_vm.handleSelectionChange}},[_c('el-table-column',{attrs:{"type":"selection","width":"55","align":"center"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"username","label":"姓名","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"mobilePhone","label":"手机号","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"orgName","label":"所属机构","width":"180"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"roleName","label":"角色","width":"240"}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"status","label":"状态","width":"180","formatter":_vm.formatterStatus}}),_vm._v(" "),_c('el-table-column',{attrs:{"prop":"createTime","label":"创建时间"}})],1),_vm._v(" "),_c('div',{staticClass:"pagination"},[_c('el-pagination',{attrs:{"background":"","layout":"prev, pager, next","prev-text":"上一页","next-text":"下一页","page-size":_vm.pageSize,"current-page":_vm.currentPage,"total":_vm.totalSize},on:{"current-change":_vm.handleCurrentChange}})],1)],1)]),_vm._v(" "),_c('el-dialog',{attrs:{"title":"新增","visible":_vm.createVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.createVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"姓名"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"姓名"},model:{value:(_vm.form.username),callback:function ($$v) {_vm.$set(_vm.form, "username", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.username"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"手机号"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"手机号"},model:{value:(_vm.form.mobilePhone),callback:function ($$v) {_vm.$set(_vm.form, "mobilePhone", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.mobilePhone"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"密码"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"type":"password","placeholder":"密码"},model:{value:(_vm.form.password),callback:function ($$v) {_vm.$set(_vm.form, "password", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.password"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"所属机构"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"filterable":"","placeholder":"所属机构"},model:{value:(_vm.form.orgId),callback:function ($$v) {_vm.$set(_vm.form, "orgId", $$v)},expression:"form.orgId"}},_vm._l((_vm.orgOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.orgName,"value":item.id}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"角色"}},_vm._l((_vm.roleOptions),function(data){return _c('el-checkbox',{key:data.id,staticStyle:{"width":"150px"},attrs:{"label":data.id},model:{value:(_vm.form.roleId),callback:function ($$v) {_vm.$set(_vm.form, "roleId", $$v)},expression:"form.roleId"}},[_vm._v("\n                "+_vm._s(data.roleName)+"\n                ")])}),1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.createVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveCreate}},[_vm._v("确 定")])],1)],1),_vm._v(" "),_c('el-dialog',{attrs:{"title":"编辑","visible":_vm.editVisible,"close-on-click-modal":false,"width":"30%"},on:{"update:visible":function($event){_vm.editVisible=$event}}},[_c('el-form',{ref:"form",attrs:{"model":_vm.form,"label-width":"120px"}},[_c('el-form-item',{attrs:{"label":"姓名"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"姓名"},model:{value:(_vm.form.username),callback:function ($$v) {_vm.$set(_vm.form, "username", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.username"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"手机号"}},[_c('el-input',{staticStyle:{"width":"200px"},attrs:{"placeholder":"手机号"},model:{value:(_vm.form.mobilePhone),callback:function ($$v) {_vm.$set(_vm.form, "mobilePhone", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"form.mobilePhone"}})],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"所属机构"}},[_c('el-select',{staticStyle:{"width":"200px"},attrs:{"filterable":"","placeholder":"所属机构"},model:{value:(_vm.form.orgId),callback:function ($$v) {_vm.$set(_vm.form, "orgId", $$v)},expression:"form.orgId"}},_vm._l((_vm.orgOptions),function(item){return _c('el-option',{key:item.id,attrs:{"label":item.orgName,"value":item.id}})}),1)],1),_vm._v(" "),_c('el-form-item',{attrs:{"label":"角色"}},_vm._l((_vm.roleOptions),function(data){return _c('el-checkbox',{key:data.id,staticStyle:{"width":"150px"},attrs:{"label":data.id},model:{value:(_vm.form.roleId),callback:function ($$v) {_vm.$set(_vm.form, "roleId", $$v)},expression:"form.roleId"}},[_vm._v("\n                "+_vm._s(data.roleName)+"\n                ")])}),1)],1),_vm._v(" "),_c('span',{staticClass:"dialog-footer",attrs:{"slot":"footer"},slot:"footer"},[_c('el-button',{on:{"click":function($event){_vm.editVisible = false}}},[_vm._v("取 消")]),_vm._v(" "),_c('el-button',{attrs:{"type":"primary"},on:{"click":_vm.saveEdit}},[_vm._v("确 定")])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_UserManage = (esExports);
// CONCATENATED MODULE: ./src/components/page/UserManage.vue
function injectStyle (ssrContext) {
  __webpack_require__("XYik")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-65cb93a7"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  UserManage,
  page_UserManage,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_UserManage = __webpack_exports__["default"] = (Component.exports);


/***/ })

});