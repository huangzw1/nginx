webpackJsonp([7],{

/***/ "2elk":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "a52u":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/page/Dashboard.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Dashboard = ({
    name: 'dashboard',
    data: function data() {
        return {};
    },

    methods: {
        getNow: function getNow() {
            return this.$moment().format('YYYY-MM-DD HH:mm:ss');
        }
    }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-31dc00cb","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/page/Dashboard.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticStyle:{"width":"100%","height":"100%"}},[_c('el-row',{staticStyle:{"min-height":"100%"},attrs:{"type":"flex","justify":"center"}},[_c('el-col',{attrs:{"span":24}},[_c('el-card',{staticClass:"mgb20",attrs:{"shadow":"hover"}},[_c('div',{staticClass:"user-info"},[_c('img',{staticClass:"user-avator",attrs:{"src":"static/img/img.jpg","alt":""}}),_vm._v(" "),_c('div',{staticClass:"user-info-cont"},[_c('div',{staticClass:"user-info-name"},[_vm._v(_vm._s(this.$session['userName']))])])]),_vm._v(" "),_c('div',{staticClass:"user-info-list"},[_vm._v("登录时间："),_c('span',[_vm._v(_vm._s(_vm.getNow()))])])])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var page_Dashboard = (esExports);
// CONCATENATED MODULE: ./src/components/page/Dashboard.vue
function injectStyle (ssrContext) {
  __webpack_require__("2elk")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-31dc00cb"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  Dashboard,
  page_Dashboard,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_page_Dashboard = __webpack_exports__["default"] = (Component.exports);


/***/ })

});